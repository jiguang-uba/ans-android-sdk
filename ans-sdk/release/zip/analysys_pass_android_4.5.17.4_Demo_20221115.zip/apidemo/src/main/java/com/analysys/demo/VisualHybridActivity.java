package com.analysys.demo;

import com.analysys.apidemo.R;

public class VisualHybridActivity extends HybridActivity {

    @Override
    protected int getContentLayoutId() {
        return R.layout.activity_visual_hybrid;
    }
}
