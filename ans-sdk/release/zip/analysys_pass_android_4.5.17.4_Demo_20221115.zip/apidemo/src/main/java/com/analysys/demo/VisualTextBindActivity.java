package com.analysys.demo;

import android.os.Bundle;

import com.analysys.apidemo.R;

public class VisualTextBindActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visual_text_bind);
    }
}
