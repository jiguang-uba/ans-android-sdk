package com.analysys.demo;

import android.os.Bundle;

import com.analysys.apidemo.R;

public class VisualRelatedActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visual_related);
    }
}
