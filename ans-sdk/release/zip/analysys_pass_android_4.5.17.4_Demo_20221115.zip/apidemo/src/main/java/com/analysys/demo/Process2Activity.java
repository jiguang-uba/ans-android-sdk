package com.analysys.demo;

import android.os.Bundle;
import android.view.View;

import com.analysys.apidemo.R;

public class Process2Activity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_process2);
    }

    public void onClick(View view) {

    }
}
